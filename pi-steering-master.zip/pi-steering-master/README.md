# pi-steering
python操作SG90双轴舵机

操作环境
python 3.5.3
RPi.GPIO 0.6.3

使用前先执行
```
$ pip install RPi.GPIO
```

```
$ python ./test.py
```
或者
```
python3 ./test.py
```
